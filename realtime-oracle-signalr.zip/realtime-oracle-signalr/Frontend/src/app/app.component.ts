// src/app/app.component.ts
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RealtimeService, Employee } from './services/realtime.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule, HttpClientModule],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent {
  // Form fields for demo insert
  newName = '';
  newDept = '';
  newSalary: number | null = null;
  inserting = false;

  constructor(public realtimeService: RealtimeService) {}

  insertRow(): void {
    if (!this.newName || !this.newDept || !this.newSalary) return;

    this.inserting = true;
    this.realtimeService
      .insertEmployee(this.newName, this.newDept, this.newSalary)
      .subscribe({
        next: () => {
          // Clear form — UI update happens automatically via SignalR
          this.newName = '';
          this.newDept = '';
          this.newSalary = null;
          this.inserting = false;
        },
        error: () => (this.inserting = false),
      });
  }
}
