// src/app/services/realtime.service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import * as signalR from '@microsoft/signalr';
import { BehaviorSubject, Observable } from 'rxjs';

export interface Employee {
  ID: string;
  NAME: string;
  DEPARTMENT: string;
  SALARY: string;
  CREATED_AT: string;
}

@Injectable({ providedIn: 'root' })
export class RealtimeService {
  private readonly apiUrl = 'http://localhost:5000/api/data';
  private readonly hubUrl = 'http://localhost:5000/hubs/data';

  // Reactive stream — Angular template subscribes via async pipe
  private dataSubject = new BehaviorSubject<Employee[]>([]);
  public data$: Observable<Employee[]> = this.dataSubject.asObservable();

  // Status stream for UI feedback
  private statusSubject = new BehaviorSubject<string>('Connecting...');
  public status$: Observable<string> = this.statusSubject.asObservable();

  private hubConnection!: signalR.HubConnection;

  constructor(private http: HttpClient) {
    this.loadInitialData();
    this.connectSignalR();
  }

  /** Step 1 — Load existing data on page load */
  private loadInitialData(): void {
    this.http.get<Employee[]>(this.apiUrl).subscribe({
      next: (rows) => this.dataSubject.next(rows),
      error: (err) => console.error('[API] Failed to load initial data', err),
    });
  }

  /** Step 2 — Open persistent WebSocket to SignalR hub */
  private connectSignalR(): void {
    this.hubConnection = new signalR.HubConnectionBuilder()
      .withUrl(this.hubUrl)
      .withAutomaticReconnect([0, 2000, 5000, 10000]) // retry delays (ms)
      .configureLogging(signalR.LogLevel.Information)
      .build();

    // ── Listen for Oracle change notifications pushed by the backend ──────
    // 'ReceiveData' must match the string used in hubContext.Clients.All.SendAsync(...)
    this.hubConnection.on('ReceiveData', (rows: Employee[]) => {
      console.log('[SignalR] Received data push:', rows.length, 'rows');
      this.dataSubject.next(rows); // Angular async pipe auto-updates the template
      this.statusSubject.next(`Live • Last updated: ${new Date().toLocaleTimeString()}`);
    });

    this.hubConnection.onreconnecting(() =>
      this.statusSubject.next('⚡ Reconnecting...')
    );

    this.hubConnection.onreconnected(() =>
      this.statusSubject.next('✓ Connected')
    );

    this.hubConnection.onclose(() =>
      this.statusSubject.next('✗ Disconnected')
    );

    // Start connection
    this.hubConnection
      .start()
      .then(() => {
        console.log('[SignalR] Connected to hub.');
        this.statusSubject.next('✓ Live');
      })
      .catch((err) => {
        console.error('[SignalR] Connection failed:', err);
        this.statusSubject.next('✗ Connection failed');
      });
  }

  /** Demo: insert a row via the API (triggers OCN → SignalR → Angular) */
  insertEmployee(name: string, department: string, salary: number): Observable<any> {
    return this.http.post(this.apiUrl, { name, department, salary });
  }
}
