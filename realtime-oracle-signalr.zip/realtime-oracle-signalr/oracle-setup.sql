-- ============================================================
-- Oracle 19c Setup Script
-- Run as DBA first, then as your application user
-- ============================================================

-- ── 1. Grant Change Notification privilege (run as DBA / SYSDBA) ──────────
GRANT CHANGE NOTIFICATION TO your_user;
GRANT EXECUTE ON DBMS_CHANGE_NOTIFICATION TO your_user;

-- Also required for OCN to call back to the .NET app:
-- The Oracle DB server must be able to reach your .NET app's host/port.
-- By default OCN uses port 1521 for callbacks; ensure firewall allows it.


-- ── 2. Create the table (run as your_user) ───────────────────────────────
CREATE TABLE EMPLOYEES (
    ID          NUMBER          PRIMARY KEY,
    NAME        VARCHAR2(100)   NOT NULL,
    DEPARTMENT  VARCHAR2(100),
    SALARY      NUMBER(12, 2),
    CREATED_AT  TIMESTAMP       DEFAULT SYSTIMESTAMP
);

-- ── 3. Sequence for auto-increment ID ────────────────────────────────────
CREATE SEQUENCE EMPLOYEES_SEQ
    START WITH 1
    INCREMENT BY 1
    NOCACHE
    NOCYCLE;

-- ── 4. Test — insert a row and watch Angular UI update in real-time ───────
INSERT INTO EMPLOYEES (ID, NAME, DEPARTMENT, SALARY, CREATED_AT)
VALUES (EMPLOYEES_SEQ.NEXTVAL, 'Neeraj Kumar', 'Engineering', 95000, SYSTIMESTAMP);
COMMIT;

-- Any INSERT here will:
--   Oracle OCN → fires OracleDependency.OnChange callback in .NET
--   .NET → re-fetches rows → pushes to SignalR hub
--   Angular → receives WebSocket message → BehaviorSubject.next() → async pipe re-renders table
--   NO TIMER. NO POLLING.
