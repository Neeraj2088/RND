// Services/OracleChangeListenerService.cs
using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Oracle.ManagedDataAccess.Client;
using RealtimeOracle.Hubs;
using System.Data;

namespace RealtimeOracle.Services;

/// <summary>
/// Background service that uses Oracle's built-in Change Notification (OCN)
/// to detect INSERT/UPDATE/DELETE on a table WITHOUT any polling or timers.
///
/// How it works:
///   1. We open an OracleConnection with change notification enabled.
///   2. We register an OracleDependency on a SELECT query.
///   3. Oracle server pushes a callback to our app whenever the result set changes.
///   4. In the callback we re-fetch the latest rows and broadcast via SignalR.
///
/// Prerequisites on Oracle:
///   GRANT CHANGE NOTIFICATION TO your_user;
///   GRANT EXECUTE ON DBMS_CHANGE_NOTIFICATION TO your_user;
/// </summary>
public class OracleChangeListenerService : BackgroundService
{
    private readonly IHubContext<DataHub> _hubContext;
    private readonly IConfiguration _config;
    private readonly ILogger<OracleChangeListenerService> _logger;

    // Keep the connection alive for the lifetime of the dependency
    private OracleConnection? _persistentConnection;
    private OracleDependency? _dependency;

    // Change the table/query to match your schema
    private const string WatchTable = "EMPLOYEES"; // ← your table name
    private const string WatchQuery = "SELECT ID, NAME, DEPARTMENT, SALARY, CREATED_AT FROM EMPLOYEES";

    public OracleChangeListenerService(
        IHubContext<DataHub> hubContext,
        IConfiguration config,
        ILogger<OracleChangeListenerService> logger)
    {
        _hubContext = hubContext;
        _config = config;
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("[Oracle OCN] Starting Oracle Change Notification listener...");

        await RegisterOracleDependencyAsync();

        // Keep the hosted service alive; OCN callbacks are event-driven
        await Task.Delay(Timeout.Infinite, stoppingToken);
    }

    private async Task RegisterOracleDependencyAsync()
    {
        try
        {
            var connectionString = _config.GetConnectionString("OracleDb")
                ?? throw new InvalidOperationException("OracleDb connection string missing.");

            // ── 1. Open a persistent connection ─────────────────────────────
            _persistentConnection = new OracleConnection(connectionString);
            await _persistentConnection.OpenAsync();

            // ── 2. Create the dependency and attach our callback ─────────────
            _dependency = new OracleDependency();
            _dependency.OnChange += OnOracleTableChanged; // ← fired by Oracle server

            // ── 3. Register the dependency on a command ──────────────────────
            using var cmd = _persistentConnection.CreateCommand();

            // Tell Oracle to notify us when this query's result set changes
            OracleDependency.Register(cmd); // Attaches dependency to command

            cmd.CommandText = WatchQuery;
            cmd.CommandType = CommandType.Text;

            // Add notification options so INSERTs are detected
            cmd.AddRowid = true;

            // Execute the query to register the subscription with Oracle server
            using var reader = await cmd.ExecuteReaderAsync();
            // Drain the reader (Oracle requires reading to complete registration)
            while (await reader.ReadAsync()) { }

            _logger.LogInformation("[Oracle OCN] Successfully registered change notification on table: {Table}", WatchTable);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "[Oracle OCN] Failed to register Oracle dependency.");
            throw;
        }
    }

    /// <summary>
    /// Oracle calls this method (on a thread pool thread) whenever
    /// an INSERT/UPDATE/DELETE modifies the watched table.
    /// No timer. No polling. Pure server push.
    /// </summary>
    private void OnOracleTableChanged(object sender, OracleNotificationEventArgs eventArgs)
    {
        _logger.LogInformation("[Oracle OCN] Change detected on table: {Table}. Info: {Info}",
            WatchTable, eventArgs.Info);

        // Re-register — OCN subscriptions are one-shot by default
        // (call Register again to keep watching)
        _ = Task.Run(async () =>
        {
            try
            {
                // Fetch fresh data and push to all Angular clients
                var rows = await FetchLatestRowsAsync();
                await _hubContext.Clients.All.SendAsync("ReceiveData", rows);
                _logger.LogInformation("[SignalR] Pushed {Count} rows to Angular clients.", rows.Count);

                // Re-register for the next change notification
                await RegisterOracleDependencyAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "[Oracle OCN] Error handling change notification.");
            }
        });
    }

    /// <summary>
    /// Fetch the current rows from the table to send to Angular.
    /// </summary>
    private async Task<List<Dictionary<string, object?>>> FetchLatestRowsAsync()
    {
        var rows = new List<Dictionary<string, object?>>();
        var connectionString = _config.GetConnectionString("OracleDb")!;

        // Use a separate short-lived connection for the data fetch
        await using var conn = new OracleConnection(connectionString);
        await conn.OpenAsync();

        await using var cmd = conn.CreateCommand();
        cmd.CommandText = WatchQuery + " ORDER BY CREATED_AT DESC FETCH FIRST 100 ROWS ONLY";

        await using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            var row = new Dictionary<string, object?>();
            for (int i = 0; i < reader.FieldCount; i++)
            {
                row[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i)?.ToString();
            }
            rows.Add(row);
        }

        return rows;
    }

    public override void Dispose()
    {
        _dependency?.Dispose();
        _persistentConnection?.Dispose();
        base.Dispose();
    }
}
