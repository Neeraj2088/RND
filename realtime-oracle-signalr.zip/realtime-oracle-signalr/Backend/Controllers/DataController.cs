// Controllers/DataController.cs
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Oracle.ManagedDataAccess.Client;
using System.Data;

namespace RealtimeOracle.Controllers;

[ApiController]
[Route("api/[controller]")]
public class DataController : ControllerBase
{
    private readonly IConfiguration _config;

    public DataController(IConfiguration config)
    {
        _config = config;
    }

    // GET api/data — initial page load, Angular fetches existing rows
    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        var rows = new List<Dictionary<string, object?>>();
        await using var conn = new OracleConnection(_config.GetConnectionString("OracleDb"));
        await conn.OpenAsync();

        await using var cmd = conn.CreateCommand();
        cmd.CommandText = @"SELECT ID, NAME, DEPARTMENT, SALARY, CREATED_AT 
                            FROM EMPLOYEES 
                            ORDER BY CREATED_AT DESC 
                            FETCH FIRST 100 ROWS ONLY";

        await using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            var row = new Dictionary<string, object?>();
            for (int i = 0; i < reader.FieldCount; i++)
                row[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i)?.ToString();
            rows.Add(row);
        }

        return Ok(rows);
    }

    // POST api/data — demo insert endpoint (simulate a row being inserted)
    [HttpPost]
    public async Task<IActionResult> Insert([FromBody] EmployeeDto dto)
    {
        await using var conn = new OracleConnection(_config.GetConnectionString("OracleDb"));
        await conn.OpenAsync();

        await using var cmd = conn.CreateCommand();
        cmd.CommandText = @"INSERT INTO EMPLOYEES (ID, NAME, DEPARTMENT, SALARY, CREATED_AT)
                            VALUES (EMPLOYEES_SEQ.NEXTVAL, :name, :dept, :salary, SYSTIMESTAMP)";

        cmd.Parameters.Add(new OracleParameter("name", dto.Name));
        cmd.Parameters.Add(new OracleParameter("dept", dto.Department));
        cmd.Parameters.Add(new OracleParameter("salary", dto.Salary));

        await cmd.ExecuteNonQueryAsync();

        // The OracleChangeListenerService will automatically detect this INSERT
        // and push the update to Angular via SignalR — no manual broadcast needed!
        return Ok(new { message = "Row inserted. UI will auto-update via SignalR." });
    }
}

public record EmployeeDto(string Name, string Department, decimal Salary);
