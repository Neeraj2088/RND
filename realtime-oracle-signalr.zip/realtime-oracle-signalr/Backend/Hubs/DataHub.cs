// Hubs/DataHub.cs
using Microsoft.AspNetCore.SignalR;

namespace RealtimeOracle.Hubs;

/// <summary>
/// SignalR hub — all connected Angular clients receive real-time pushes here.
/// Angular connects to: ws://localhost:5000/hubs/data
/// </summary>
public class DataHub : Hub
{
    // Called automatically when Angular client connects
    public override async Task OnConnectedAsync()
    {
        Console.WriteLine($"[SignalR] Client connected: {Context.ConnectionId}");
        await base.OnConnectedAsync();
    }

    // Called automatically when Angular client disconnects
    public override async Task OnDisconnectedAsync(Exception? exception)
    {
        Console.WriteLine($"[SignalR] Client disconnected: {Context.ConnectionId}");
        await base.OnDisconnectedAsync(exception);
    }
}
