// Program.cs
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using RealtimeOracle.Hubs;
using RealtimeOracle.Services;

var builder = WebApplication.CreateBuilder(args);

// ── Services ────────────────────────────────────────────────────────────────
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// SignalR — the WebSocket/long-polling hub
builder.Services.AddSignalR();

// Background service: listens to Oracle Change Notifications
// Registered as Singleton so it shares the same hub context
builder.Services.AddSingleton<OracleChangeListenerService>();
builder.Services.AddHostedService(sp => sp.GetRequiredService<OracleChangeListenerService>());

// CORS — allow Angular dev server
builder.Services.AddCors(options =>
{
    options.AddPolicy("AngularPolicy", policy =>
        policy.WithOrigins("http://localhost:4200")
              .AllowAnyHeader()
              .AllowAnyMethod()
              .AllowCredentials()); // Required for SignalR WebSockets
});

var app = builder.Build();

// ── Middleware ───────────────────────────────────────────────────────────────
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseCors("AngularPolicy");
app.UseAuthorization();

app.MapControllers();

// Map the SignalR hub at /hubs/data
app.MapHub<DataHub>("/hubs/data");

app.Run();
