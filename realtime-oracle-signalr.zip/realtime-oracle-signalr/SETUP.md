# Setup & Run Guide

## Prerequisites
- Oracle 19c with Change Notification enabled
- .NET 8 SDK
- Node.js 18+ / Angular CLI 17

---

## Step 1 — Oracle Setup

```sql
-- Run as SYSDBA
GRANT CHANGE NOTIFICATION TO your_user;
GRANT EXECUTE ON DBMS_CHANGE_NOTIFICATION TO your_user;
```

Then run `oracle-setup.sql` as your application user.

**Important network note:** Oracle pushes change notifications back to your .NET server.
The Oracle DB host must be able to reach your .NET machine on the callback port.
For local dev (both on same machine), this works automatically.

---

## Step 2 — Configure Backend

Edit `Backend/appsettings.json`:
```json
"OracleDb": "User Id=YOUR_USER;Password=YOUR_PASS;Data Source=YOUR_HOST:1521/YOUR_SERVICE;"
```

Edit `Backend/Services/OracleChangeListenerService.cs` — set your table and columns:
```csharp
private const string WatchTable = "EMPLOYEES";
private const string WatchQuery = "SELECT ID, NAME, DEPARTMENT, SALARY, CREATED_AT FROM EMPLOYEES";
```

---

## Step 3 — Run Backend

```bash
cd Backend
dotnet restore
dotnet run
# API: http://localhost:5000
# SignalR hub: ws://localhost:5000/hubs/data
```

---

## Step 4 — Run Angular Frontend

```bash
cd Frontend
npm install
ng serve
# App: http://localhost:4200
```

---

## Step 5 — Test Real-Time

**Option A** — Use the form in the UI to insert a row.

**Option B** — Run SQL directly on Oracle:
```sql
INSERT INTO EMPLOYEES (ID, NAME, DEPARTMENT, SALARY, CREATED_AT)
VALUES (EMPLOYEES_SEQ.NEXTVAL, 'Test User', 'Sales', 75000, SYSTIMESTAMP);
COMMIT;
```

Watch the Angular table update **instantly** — no refresh, no timer.

---

## How It Works (Data Flow)

```
1. Any INSERT into EMPLOYEES table
        ↓
2. Oracle 19c detects change (Change Notification / OCN)
        ↓
3. Oracle pushes notification to .NET app's OracleDependency.OnChange event
        ↓
4. OracleChangeListenerService re-fetches latest rows from DB
        ↓
5. Broadcasts to all connected clients via SignalR hub
        ↓ WebSocket
6. Angular's RealtimeService receives 'ReceiveData' event
        ↓
7. BehaviorSubject.next(rows) called
        ↓
8. Angular async pipe re-renders the table automatically
```

**Zero timers. Zero polling. Pure event-driven.**

---

## Troubleshooting

| Issue | Fix |
|---|---|
| `ORA-29970: Specified registration id does not exist` | Run `GRANT CHANGE NOTIFICATION TO user` again |
| OCN not firing | Ensure Oracle can reach .NET host (check firewall) |
| SignalR CORS error | Confirm `WithOrigins("http://localhost:4200")` in Program.cs |
| Angular not updating | Open browser console — check SignalR connection status |
