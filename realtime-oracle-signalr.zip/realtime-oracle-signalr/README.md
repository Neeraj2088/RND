# Real-Time Oracle → Angular via SignalR (No Timers)

## Architecture
```
Oracle 19c (OracleDependency/Change Notification)
    ↓
.NET Core Web API (SignalR Hub + OracleChangeListener)
    ↓ WebSocket
Angular 17 (SignalR Client → Auto-refresh UI)
```

---

## Project Structure
```
solution/
├── Backend/                    ← .NET Core 8 Web API
│   ├── Program.cs
│   ├── appsettings.json
│   ├── Hubs/
│   │   └── DataHub.cs
│   ├── Services/
│   │   └── OracleChangeListenerService.cs
│   └── Controllers/
│       └── DataController.cs
└── Frontend/                   ← Angular 17 App
    ├── src/
    │   ├── app/
    │   │   ├── app.component.ts
    │   │   ├── app.component.html
    │   │   ├── app.component.scss
    │   │   └── services/
    │   │       └── realtime.service.ts
    │   └── styles.scss
    └── package.json
```
