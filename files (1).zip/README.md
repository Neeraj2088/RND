# Oracle LLM Query System

Ask plain-English questions about your Oracle records.
The system routes each query through the right pipeline automatically.

```
User Query
    │
IntentDetector ──── has IDs/trade refs? ────────────────────────────────┐
    │  NO                                                                YES
    ▼                                                                    ▼
VectorDB                                                           VectorDB
(fetch specs)                                                      (fetch specs)
    │                                                                    │
    ▼                                                              SchemaRegistry
LLM explains                                                       (load schema map)
spec rules only                                                          │
    │                                                              QueryPlanner
    ▼                                                        (LLM builds SQL plan)
Answer ✓                                                                 │
                                                                   OracleDB
                                                                (execute safe SQL)
                                                                         │
                                                              LLM Reasoning
                                                          (spec + live data → answer)
                                                                         │
                                                                    Answer ✓
```

---

## Files

```
oracle_llm_system/
├── main.py                  ← Entry point (interactive CLI)
├── agent.py                 ← Full pipeline orchestrator
├── intent_detector.py       ← Classifies query, extracts IDs/trade refs
├── schema_registry.py       ← Loads + validates oracle_schema.json
├── vector_store.py          ← ChromaDB / Pinecone abstraction
├── oracle_db.py             ← Safe Oracle query executor
├── llm_client.py            ← Anthropic Claude wrapper
├── query_planner.py         ← LLM → SQL plan → validated SQL
├── load_specs.py            ← One-time: load spec docs into Vector DB
├── config.py                ← All config from .env
├── requirements.txt
└── .env.template
```

---

## Setup (3 steps)

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Configure environment
```bash
cp .env.template .env
# Edit .env — fill in Oracle credentials + Anthropic API key
```

### 3. Build schema + load specs

**A. Generate the schema map from your Oracle DB:**
```bash
# From the parent folder (where oracle_schema_discovery.py lives)
python oracle_schema_discovery.py --output oracle_llm_system/oracle_schema.json
```

**B. Load your specification documents:**
```bash
cd oracle_llm_system
python load_specs.py --dir ./specs          # folder of PDFs/TXTs
python load_specs.py --file my_spec.pdf     # single file
```

---

## Run

```bash
python main.py
```

---

## Example Queries

**With a record ID — triggers DB lookup + reasoning:**
```
You: why is event_id 78234 falling into category B?
You: explain trade TRD-00456 calculation
You: what is wrong with record 99100 premium amount
You: why is trade reference REF-2024-0089 flagged
```

**Without an ID — returns spec explanation only:**
```
You: what is the rule for category B classification?
You: explain the premium calculation formula
You: what threshold triggers a trade flag?
You: describe the criteria for margin calls
```

---

## How the Intent Detector Works

The `IntentDetector` uses regex patterns — no LLM call needed:

| Pattern                        | Example Match         | Result        |
|--------------------------------|-----------------------|---------------|
| `event_id=12345`               | "event_id 78234"      | record_id     |
| `TRD-XXXXX`                    | "TRD-00456"           | trade_ref     |
| `REF-*`, `DEAL-*`, `TXN-*`    | "REF-2024-0089"       | trade_ref     |
| Bare 5+ digit number           | "99100"               | record_id     |
| No ID + rule/spec keywords     | "what is the rule…"   | spec_only     |

---

## Security

- LLM never executes SQL directly — it only produces a JSON plan.
- Every table and column in the plan is validated against the schema whitelist.
- All queries use Oracle bind variables (`:record_id`) — no SQL injection possible.
- Only SELECT is permitted — DML/DDL is blocked at the executor level.
- `max_rows` cap prevents accidental full-table scans.

---

## Adding More Spec Documents

```bash
python load_specs.py --dir ./new_specs --chunk-size 800
```
Re-run anytime. Existing chunks are updated (upsert), not duplicated.

---

## Updating the Schema

When new tables are added to Oracle:
```bash
python oracle_schema_discovery.py --output oracle_schema.json
# Then enrich the TODO fields in oracle_schema.json manually
```
