"""
load_specs.py
=============
One-time utility to load your functional specification documents
into the vector database.

Supports: .txt, .pdf, .md files

Usage:
    python load_specs.py --dir ./specs
    python load_specs.py --file trade_calc_spec.pdf
    python load_specs.py --dir ./specs --chunk-size 800
"""

import argparse
import hashlib
import os
import sys
from pathlib import Path
from vector_store import get_vector_store


def chunk_text(text: str, chunk_size: int = 600, overlap: int = 100) -> list[str]:
    """Split text into overlapping chunks."""
    words  = text.split()
    chunks = []
    start  = 0
    while start < len(words):
        end   = min(start + chunk_size, len(words))
        chunk = " ".join(words[start:end])
        chunks.append(chunk)
        start += chunk_size - overlap
    return chunks


def read_pdf(path: Path) -> str:
    try:
        import pdfplumber
        with pdfplumber.open(path) as pdf:
            return "\n".join(
                page.extract_text() or "" for page in pdf.pages
            )
    except ImportError:
        raise ImportError("Install pdfplumber: pip install pdfplumber")


def read_file(path: Path) -> str:
    suffix = path.suffix.lower()
    if suffix == ".pdf":
        return read_pdf(path)
    return path.read_text(encoding="utf-8", errors="ignore")


def load_directory(directory: str, chunk_size: int, overlap: int):
    dir_path = Path(directory)
    if not dir_path.exists():
        print(f"❌ Directory not found: {directory}")
        sys.exit(1)

    files = list(dir_path.rglob("*.txt")) + \
            list(dir_path.rglob("*.pdf")) + \
            list(dir_path.rglob("*.md"))

    if not files:
        print(f"⚠️  No .txt / .pdf / .md files found in {directory}")
        return

    print(f"📂 Found {len(files)} file(s) in {directory}")
    _process_files(files, chunk_size, overlap)


def load_single_file(filepath: str, chunk_size: int, overlap: int):
    path = Path(filepath)
    if not path.exists():
        print(f"❌ File not found: {filepath}")
        sys.exit(1)
    _process_files([path], chunk_size, overlap)


def _process_files(files: list, chunk_size: int, overlap: int):
    vector_db = get_vector_store()
    total_chunks = 0

    for file_path in files:
        print(f"\n  📄 Processing: {file_path.name}")
        try:
            text   = read_file(file_path)
            chunks = chunk_text(text, chunk_size, overlap)
            print(f"     → {len(chunks)} chunk(s)")

            records = []
            for i, chunk in enumerate(chunks):
                chunk_id = hashlib.md5(
                    f"{file_path.name}:{i}:{chunk[:50]}".encode()
                ).hexdigest()
                records.append({
                    "id"      : chunk_id,
                    "text"    : chunk,
                    "metadata": {
                        "source" : file_path.name,
                        "path"   : str(file_path),
                        "chunk"  : i,
                        "total"  : len(chunks),
                    },
                })
            vector_db.upsert(records)
            total_chunks += len(chunks)

        except Exception as e:
            print(f"     ❌ Error: {e}")

    print(f"\n✅ Loaded {total_chunks} total chunk(s) into vector DB.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Load spec docs into Vector DB")
    parser.add_argument("--dir",        help="Directory of spec files")
    parser.add_argument("--file",       help="Single spec file")
    parser.add_argument("--chunk-size", type=int, default=600)
    parser.add_argument("--overlap",    type=int, default=100)
    args = parser.parse_args()

    if args.dir:
        load_directory(args.dir, args.chunk_size, args.overlap)
    elif args.file:
        load_single_file(args.file, args.chunk_size, args.overlap)
    else:
        parser.print_help()
