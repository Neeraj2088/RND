"""
intent_detector.py
==================
Analyses the user query and extracts:
  - intent_type   : "db_lookup" | "spec_only" | "ambiguous"
  - record_ids    : list of numeric IDs found  (e.g. event_id, trade_id)
  - trade_refs    : list of trade reference strings (e.g. TRD-00123, REF-ABC)
  - raw_keywords  : other notable keywords
  - anchor_entity : best guess at what the ID refers to (event / trade / policy …)
"""

import re
from dataclasses import dataclass, field


# ── Patterns ────────────────────────────────────────────────────────────────

# Numeric IDs:  "event 12345", "event_id=12345", "id: 12345"
_NUMERIC_ID_PATTERN = re.compile(
    r"""
    (?:
        event[_\s-]?id   |
        trade[_\s-]?id   |
        policy[_\s-]?id  |
        claim[_\s-]?id   |
        record[_\s-]?id  |
        order[_\s-]?id   |
        id
    )
    [\s:=]*
    (\d{4,})                  # at least 4 digits
    """,
    re.IGNORECASE | re.VERBOSE,
)

# Standalone large numbers that look like IDs
_BARE_NUMBER_PATTERN = re.compile(r"\b(\d{5,})\b")

# Trade / deal references:  TRD-00123, REF-ABC-001, DEAL/2024/00099
_TRADE_REF_PATTERN = re.compile(
    r"""
    (?:
        TRD|REF|DEAL|TXN|ORD|EVT|CLM|POL|TREF
    )
    [-/]?
    [A-Z0-9]{2,}
    (?:[-/][A-Z0-9]+)*
    """,
    re.IGNORECASE | re.VERBOSE,
)

# Keywords that indicate the user wants DB data
_DB_INTENT_KEYWORDS = re.compile(
    r"\b(why|how|what|calculate|calculated|falling|category|flag|flagged|"
    r"result|value|record|show|fetch|explain this|look up|look at|check)\b",
    re.IGNORECASE,
)

# Keywords that suggest spec-only questions
_SPEC_INTENT_KEYWORDS = re.compile(
    r"\b(rule|rules|logic|spec|specification|policy|definition|criteria|"
    r"threshold|formula|how does|what is the rule|describe|explain the rule)\b",
    re.IGNORECASE,
)


@dataclass
class IntentResult:
    intent_type   : str          # "db_lookup" | "spec_only" | "ambiguous"
    record_ids    : list = field(default_factory=list)
    trade_refs    : list = field(default_factory=list)
    raw_keywords  : list = field(default_factory=list)
    anchor_entity : str  = ""    # e.g. "event", "trade", "policy"
    confidence    : str  = "LOW" # LOW | MEDIUM | HIGH

    def has_identifiers(self) -> bool:
        return bool(self.record_ids or self.trade_refs)

    def summary(self) -> str:
        parts = [f"intent={self.intent_type}"]
        if self.record_ids:  parts.append(f"ids={self.record_ids}")
        if self.trade_refs:  parts.append(f"refs={self.trade_refs}")
        if self.anchor_entity: parts.append(f"entity={self.anchor_entity}")
        return " | ".join(parts)


# ── Detector ─────────────────────────────────────────────────────────────────

class IntentDetector:
    """
    Rule-based + lightweight NLP intent detector.
    No LLM call needed — fast and deterministic.
    """

    # Map common noun mentions → entity hint for schema lookup
    _ENTITY_HINTS = {
        "event"   : ["event", "evt", "event_id"],
        "trade"   : ["trade", "trd", "tref", "deal", "txn"],
        "policy"  : ["policy", "pol"],
        "claim"   : ["claim", "clm"],
        "order"   : ["order", "ord"],
        "payment" : ["payment", "pay"],
    }

    def detect(self, query: str) -> IntentResult:
        result = IntentResult(intent_type="ambiguous")

        # 1. Extract numeric IDs (labelled)
        for match in _NUMERIC_ID_PATTERN.finditer(query):
            result.record_ids.append(match.group(1))

        # 2. Extract trade/deal references
        for match in _TRADE_REF_PATTERN.finditer(query):
            result.trade_refs.append(match.group(0).upper())

        # 3. Bare large numbers as fallback IDs
        if not result.record_ids:
            for match in _BARE_NUMBER_PATTERN.finditer(query):
                result.record_ids.append(match.group(1))

        # 4. Deduplicate
        result.record_ids = list(dict.fromkeys(result.record_ids))
        result.trade_refs = list(dict.fromkeys(result.trade_refs))

        # 5. Determine intent
        has_ids      = result.has_identifiers()
        db_signals   = bool(_DB_INTENT_KEYWORDS.search(query))
        spec_signals = bool(_SPEC_INTENT_KEYWORDS.search(query))

        if has_ids and (db_signals or not spec_signals):
            result.intent_type = "db_lookup"
            result.confidence  = "HIGH" if db_signals else "MEDIUM"
        elif spec_signals and not has_ids:
            result.intent_type = "spec_only"
            result.confidence  = "HIGH"
        elif has_ids:
            result.intent_type = "db_lookup"
            result.confidence  = "MEDIUM"
        else:
            result.intent_type = "spec_only"
            result.confidence  = "LOW"

        # 6. Identify anchor entity
        query_lower = query.lower()
        for entity, hints in self._ENTITY_HINTS.items():
            if any(h in query_lower for h in hints):
                result.anchor_entity = entity
                break

        # 7. Collect raw notable keywords
        result.raw_keywords = list({
            w.lower() for w in re.findall(r"\b[a-zA-Z_]{4,}\b", query)
            if w.lower() not in {"this", "that", "with", "from", "what",
                                  "when", "where", "have", "been", "will",
                                  "they", "their", "there"}
        })

        return result
