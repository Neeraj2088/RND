"""
llm_client.py
=============
Thin wrapper around the Anthropic Messages API.
Exposes:
  - chat(messages, system)         multi-turn conversation
  - complete(prompt, system)       single-turn convenience
  - extract_json(prompt, system)   forces JSON output and parses it
"""

from __future__ import annotations
import json
import re
import anthropic
from config import Config


class LLMClient:

    def __init__(self):
        self._client = anthropic.Anthropic(api_key=Config.ANTHROPIC_API_KEY)
        self._model  = Config.LLM_MODEL

    # ── Core call ────────────────────────────────────────────────────

    def chat(
        self,
        messages   : list[dict],   # [{"role": "user"|"assistant", "content": "..."}]
        system     : str = "",
        max_tokens : int = None,
    ) -> str:
        response = self._client.messages.create(
            model      = self._model,
            max_tokens = max_tokens or Config.LLM_MAX_TOKENS,
            system     = system,
            messages   = messages,
        )
        return response.content[0].text

    def complete(self, prompt: str, system: str = "") -> str:
        return self.chat(
            messages = [{"role": "user", "content": prompt}],
            system   = system,
        )

    # ── JSON extraction ───────────────────────────────────────────────

    def extract_json(self, prompt: str, system: str = "") -> dict | list:
        """
        Ask the LLM to respond with pure JSON.
        Strips markdown fences and parses safely.
        Raises ValueError if response is not valid JSON.
        """
        json_system = (
            (system + "\n\n" if system else "") +
            "IMPORTANT: Respond ONLY with valid JSON. "
            "No explanation, no markdown fences, no extra text."
        )
        raw = self.complete(prompt, system=json_system)

        # Strip possible ```json ... ``` fences
        cleaned = re.sub(r"^```(?:json)?\s*", "", raw.strip(), flags=re.IGNORECASE)
        cleaned = re.sub(r"\s*```$", "", cleaned.strip())

        try:
            return json.loads(cleaned)
        except json.JSONDecodeError as e:
            raise ValueError(
                f"LLM did not return valid JSON.\nError: {e}\nRaw:\n{raw}"
            )
