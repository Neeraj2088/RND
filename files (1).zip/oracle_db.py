"""
oracle_db.py
============
Safe Oracle database connector.
  - execute_query()    run a SELECT with bind variables
  - rows_to_dict()     convert cx_Oracle rows → list of dicts
  - test_connection()  health check
"""

from __future__ import annotations
import cx_Oracle
from config import Config


class OracleDB:

    def __init__(self):
        self._conn = None

    def connect(self):
        if self._conn:
            return
        try:
            self._conn = cx_Oracle.connect(
                user     = Config.ORACLE_USER,
                password = Config.ORACLE_PASSWORD,
                dsn      = Config.ORACLE_DSN,
            )
            print(f"✅ Oracle connected — {Config.ORACLE_USER}@{Config.ORACLE_DSN}")
        except cx_Oracle.DatabaseError as e:
            raise ConnectionError(f"Oracle connection failed: {e}")

    def disconnect(self):
        if self._conn:
            self._conn.close()
            self._conn = None

    # ── Core query runner ────────────────────────────────────────────

    def execute_query(
        self,
        sql        : str,
        bind_vars  : dict = None,
        max_rows   : int  = None,
    ) -> list[dict]:
        """
        Execute a parameterised SELECT and return rows as list of dicts.
        bind_vars: { ":record_id": "12345", ... }  OR  { "record_id": "12345" }

        Security:
          - Only SELECT statements are executed; DML is blocked.
          - Bind variables prevent SQL injection.
          - max_rows caps accidental full-table scans.
        """
        if self._conn is None:
            self.connect()

        # Block DML
        sql_upper = sql.strip().upper()
        forbidden = ("INSERT", "UPDATE", "DELETE", "DROP",
                     "TRUNCATE", "ALTER", "CREATE", "MERGE")
        for kw in forbidden:
            if sql_upper.startswith(kw):
                raise PermissionError(
                    f"DML/DDL not allowed. Blocked keyword: {kw}"
                )

        # Strip leading colons from bind var keys if present
        cleaned_binds = {}
        if bind_vars:
            for k, v in bind_vars.items():
                cleaned_binds[k.lstrip(":")] = v

        # Inject ROWNUM cap if requested
        if max_rows:
            if "WHERE" in sql_upper:
                sql = sql.rstrip().rstrip(";") + f"\nAND ROWNUM <= {max_rows}"
            else:
                sql = sql.rstrip().rstrip(";") + f"\nWHERE ROWNUM <= {max_rows}"

        cursor = self._conn.cursor()
        try:
            cursor.execute(sql, cleaned_binds or {})
            cols    = [d[0] for d in cursor.description]
            rows    = cursor.fetchall()
            return [dict(zip(cols, row)) for row in rows]
        except cx_Oracle.DatabaseError as e:
            raise RuntimeError(f"Oracle query error: {e}\nSQL:\n{sql}")
        finally:
            cursor.close()

    # ── Health check ─────────────────────────────────────────────────

    def test_connection(self) -> bool:
        try:
            self.connect()
            result = self.execute_query("SELECT 1 FROM DUAL")
            return bool(result)
        except Exception:
            return False

    # ── Context manager support ──────────────────────────────────────

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, *args):
        self.disconnect()
