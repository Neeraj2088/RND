"""
Oracle LLM Query System — Main Entry Point
==========================================
Run:  python main.py
"""

import asyncio
from agent import OracleLLMAgent


async def main():
    agent = OracleLLMAgent()
    await agent.initialize()

    print("\n" + "═" * 60)
    print("  Oracle LLM Query Assistant")
    print("  Type 'quit' to exit | 'reset' to clear history")
    print("═" * 60)

    while True:
        try:
            user_input = input("\n You: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye.")
            break

        if not user_input:
            continue
        if user_input.lower() == "quit":
            print("Goodbye.")
            break
        if user_input.lower() == "reset":
            agent.reset_conversation()
            print("Conversation history cleared.")
            continue

        response = await agent.process(user_input)
        print(f"\n Assistant:\n{response}")


if __name__ == "__main__":
    asyncio.run(main())
