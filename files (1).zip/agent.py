"""
agent.py
========
OracleLLMAgent — the full pipeline orchestrator.

Decision tree:
  ┌─────────────────────────────────────────────┐
  │  User query                                 │
  └───────────────┬─────────────────────────────┘
                  │
          IntentDetector
                  │
      ┌───────────┴───────────┐
  has IDs/refs?           no IDs/refs
      │                       │
  db_lookup              spec_only
      │                       │
  VectorDB (specs)       VectorDB (specs)
      │                       │
  SchemaRegistry         Return spec
      │                  explanation
  QueryPlanner               │
      │                    done ✓
  OracleDB.execute
      │
  LLM reasoning
  (spec + live data)
      │
  Plain English answer
      │
    done ✓
"""

from __future__ import annotations
import json
from intent_detector import IntentDetector
from schema_registry import SchemaRegistry
from vector_store    import get_vector_store
from oracle_db       import OracleDB
from llm_client      import LLMClient
from query_planner   import QueryPlanner
from config          import Config


# ── System prompts ────────────────────────────────────────────────────────────

_SPEC_ONLY_SYSTEM = """
You are a knowledgeable business analyst assistant.
You have been given relevant functional specification text.
Answer the user's question using ONLY the specification provided.
Be clear, structured, and reference specific rules or conditions from the spec.
If the spec does not cover the question, say so honestly.
"""

_DB_REASONING_SYSTEM = """
You are a data analyst and business rules expert.
You have been given:
  1. A USER QUESTION about a specific record.
  2. FUNCTIONAL SPECIFICATION describing the business rules.
  3. ACTUAL DATA retrieved from the Oracle database for that record.

Your job:
  - Compare the actual data values against the business rules in the spec.
  - Identify which specific condition(s) caused this record to be
    categorised / flagged / calculated the way it was.
  - Explain in plain English, referencing actual column values and the spec.
  - Structure your answer as:
      SUMMARY  — one-sentence verdict
      REASON   — step-by-step logic with data values
      DATA REF — which columns/values were the deciding factors
  - If data is missing or insufficient to answer fully, say so.
  - Do NOT invent values. Only use what is in the provided data.
"""


class OracleLLMAgent:

    def __init__(self):
        self._detector  = IntentDetector()
        self._llm       = LLMClient()
        self._db        = OracleDB()
        self._registry  = None
        self._vector_db = None
        self._planner   = None
        self._history   : list[dict] = []   # conversation memory

    async def initialize(self):
        """Load schema, connect vector DB. Call once at startup."""
        print("\n🚀 Initialising Oracle LLM Agent...")

        # Schema registry
        try:
            self._registry = SchemaRegistry(Config.SCHEMA_FILE)
            print(f"✅ Schema registry loaded from {Config.SCHEMA_FILE}")
        except FileNotFoundError as e:
            print(f"⚠️  {e}")
            print("   Running without schema — DB queries will be disabled.")

        # Vector DB
        try:
            self._vector_db = get_vector_store()
        except Exception as e:
            print(f"⚠️  Vector DB unavailable: {e}")
            print("   Spec lookups will return empty results.")

        # Query planner (needs both registry and LLM)
        if self._registry:
            self._planner = QueryPlanner(self._llm, self._registry)

        print("✅ Agent ready.\n")

    def reset_conversation(self):
        self._history.clear()

    # ── Main entry point ──────────────────────────────────────────────

    async def process(self, user_query: str) -> str:
        """
        Route the query through the correct pipeline and return
        a plain-English response.
        """
        print(f"\n{'─'*55}")
        print(f"  Query: {user_query}")

        # ── Step 1: Detect intent ─────────────────────────────────────
        intent = self._detector.detect(user_query)
        print(f"  {intent.summary()}")

        # ── Step 2: Fetch specs from Vector DB ────────────────────────
        spec_chunks = self._fetch_specs(user_query)
        spec_context = self._format_spec_context(spec_chunks)

        # ── Step 3: Route ─────────────────────────────────────────────
        if intent.intent_type == "spec_only" or not intent.has_identifiers():
            return await self._handle_spec_only(user_query, spec_context)
        else:
            return await self._handle_db_lookup(user_query, intent, spec_context)

    # ── Route A: Spec-only ────────────────────────────────────────────

    async def _handle_spec_only(self, query: str, spec_context: str) -> str:
        print("  ➤ Route: SPEC ONLY")

        if not spec_context.strip():
            return (
                "I could not find relevant specification content for your question. "
                "Please check that your specification documents are loaded into the "
                "vector database, or rephrase your question."
            )

        prompt = (
            f"FUNCTIONAL SPECIFICATION:\n{spec_context}\n\n"
            f"USER QUESTION: {query}"
        )
        self._history.append({"role": "user", "content": prompt})
        answer = self._llm.chat(self._history, system=_SPEC_ONLY_SYSTEM)
        self._history.append({"role": "assistant", "content": answer})
        return answer

    # ── Route B: DB lookup + reasoning ───────────────────────────────

    async def _handle_db_lookup(
        self,
        query      : str,
        intent,
        spec_context: str,
    ) -> str:
        print("  ➤ Route: DB LOOKUP + REASONING")

        if not self._registry or not self._planner:
            return (
                "Schema registry is not loaded so I cannot query the database. "
                "Run oracle_schema_discovery.py first and set SCHEMA_FILE in .env.\n\n"
                f"Here is what the specification says:\n\n{spec_context}"
            )

        # Consolidate all IDs/refs found
        all_identifiers = intent.record_ids + intent.trade_refs
        responses       = []

        for record_id in all_identifiers:
            print(f"\n  Processing record: {record_id}")
            result = await self._process_single_record(
                query, intent, spec_context, record_id
            )
            responses.append(result)

        combined = "\n\n" + ("─" * 50 + "\n\n").join(responses)
        self._history.append({"role": "user",      "content": query})
        self._history.append({"role": "assistant", "content": combined})
        return combined

    async def _process_single_record(
        self,
        query        : str,
        intent,
        spec_context : str,
        record_id    : str,
    ) -> str:

        # ── Step A: Build query plan ──────────────────────────────────
        try:
            print(f"    🧠 Planning query for record {record_id}...")
            plan = self._planner.plan(
                user_question = query,
                spec_context  = spec_context,
                record_id     = record_id,
                entity_hint   = intent.anchor_entity,
            )
            print(f"    📋 SQL plan:")
            print(f"       {plan.raw_sql.replace(chr(10), chr(10) + '       ')}")
        except Exception as e:
            return (
                f"⚠️ Could not build query plan for record {record_id}.\n"
                f"Error: {e}\n\n"
                f"Spec-based answer only:\n{spec_context}"
            )

        # ── Step B: Execute against Oracle ───────────────────────────
        try:
            print(f"    🔍 Querying Oracle...")
            rows = self._db.execute_query(
                sql       = plan.raw_sql,
                bind_vars = {"record_id": record_id},
                max_rows  = Config.SAMPLE_ROWS_LIMIT,
            )
            print(f"    ✅ {len(rows)} row(s) returned")
        except Exception as e:
            return (
                f"⚠️ Database query failed for record {record_id}.\n"
                f"Error: {e}\n\n"
                f"Spec-based answer only:\n{spec_context}"
            )

        if not rows:
            return (
                f"No data found in the database for record ID: {record_id}.\n"
                "Please verify the ID is correct.\n\n"
                f"The specification says:\n{spec_context}"
            )

        # ── Step C: LLM reasons over spec + live data ─────────────────
        db_data_str = json.dumps(rows, indent=2, default=str)

        reasoning_prompt = f"""
FUNCTIONAL SPECIFICATION (business rules):
{spec_context}

ACTUAL DATABASE DATA for Record ID {record_id}:
{db_data_str}

USER QUESTION: {query}

Using the specification rules and the actual data values above, explain
why this record is categorised / calculated the way it is.
"""
        print(f"    💡 Reasoning with LLM...")
        answer = self._llm.complete(reasoning_prompt, system=_DB_REASONING_SYSTEM)
        return f"Record ID: {record_id}\n\n{answer}"

    # ── Spec helpers ──────────────────────────────────────────────────

    def _fetch_specs(self, query: str) -> list:
        if not self._vector_db:
            return []
        try:
            chunks = self._vector_db.search(query, top_k=Config.SPEC_TOP_K)
            print(f"  📚 {len(chunks)} spec chunk(s) retrieved")
            return chunks
        except Exception as e:
            print(f"  ⚠️  Spec fetch failed: {e}")
            return []

    def _format_spec_context(self, chunks: list) -> str:
        if not chunks:
            return ""
        parts = []
        for i, chunk in enumerate(chunks, 1):
            src   = chunk.metadata.get("source", "spec")
            score = chunk.score
            parts.append(f"[Spec {i} | source: {src} | relevance: {score:.2f}]\n{chunk.text}")
        return "\n\n---\n\n".join(parts)
