"""
query_planner.py
================
Uses the LLM to produce a validated SQL query plan, then builds
a safe parameterised Oracle SQL string.

Flow:
  1. LLM receives schema context + spec context + user question
  2. LLM returns a structured JSON plan (tables, columns, joins, filters)
  3. SchemaRegistry validates every table and column against whitelist
  4. build_sql() assembles the final parameterised SELECT
"""

from __future__ import annotations
import json
from dataclasses import dataclass, field
from llm_client      import LLMClient
from schema_registry import SchemaRegistry
from config          import Config


@dataclass
class QueryPlan:
    anchor_table      : str
    anchor_key_column : str
    tables_needed     : list = field(default_factory=list)
    columns_needed    : dict = field(default_factory=dict)  # {table: [col, ...]}
    join_path         : list = field(default_factory=list)  # [{from, to, on}]
    filter_conditions : list = field(default_factory=list)  # extra WHERE clauses
    order_by          : list = field(default_factory=list)
    raw_sql           : str  = ""   # filled in by build_sql()


PLAN_SYSTEM = """
You are a SQL architect for an Oracle database.
You will be given:
  1. A DATABASE SCHEMA describing available tables and columns.
  2. FUNCTIONAL SPECIFICATION TEXT describing business rules.
  3. A USER QUESTION about a specific record.

Your job is to produce a JSON query plan — NOT raw SQL.

Return ONLY this JSON structure (no explanation, no markdown):
{
  "anchor_table"      : "TABLE_NAME",
  "anchor_key_column" : "COLUMN_NAME",
  "tables_needed"     : ["TABLE1", "TABLE2"],
  "columns_needed"    : {
    "TABLE1": ["COL_A", "COL_B"],
    "TABLE2": ["COL_C", "COL_D"]
  },
  "join_path": [
    { "from": "TABLE1", "to": "TABLE2", "on": "TABLE1.COL = TABLE2.COL" }
  ],
  "filter_conditions" : [],
  "order_by"          : []
}

Rules:
- Only use tables and columns that exist in the schema provided.
- The anchor_table is the table whose PK matches the user's record ID.
- Include every column that is relevant to answer the business question.
- Do NOT add ROWNUM, FETCH FIRST, or LIMIT — the application adds those.
- Do NOT use SELECT * — list specific columns only.
- Use UPPERCASE for all table and column names.
- If the spec references a calculation, include all input columns for it.
"""


class QueryPlanner:

    def __init__(self, llm: LLMClient, registry: SchemaRegistry):
        self._llm      = llm
        self._registry = registry

    def plan(
        self,
        user_question  : str,
        spec_context   : str,
        record_id      : str,
        entity_hint    : str = "",
    ) -> QueryPlan:
        """
        Ask the LLM to build a query plan, validate it, then return it.
        """
        # Resolve anchor table from entity hint
        anchor_table = None
        if entity_hint:
            anchor_table = self._registry.get_anchor_table(entity_hint)

        schema_ctx = self._registry.get_llm_context(
            tables_hint=[anchor_table] if anchor_table else None
        )

        prompt = f"""
DATABASE SCHEMA:
{schema_ctx}

FUNCTIONAL SPECIFICATION (business rules relevant to the question):
{spec_context}

USER QUESTION: {user_question}
RECORD ID    : {record_id}
ENTITY HINT  : {entity_hint or 'unknown'}

Based on the schema and the spec, produce the JSON query plan to retrieve
all data needed to answer why this record is categorised this way.
"""
        raw_plan = self._llm.extract_json(prompt, system=PLAN_SYSTEM)

        # ── Validate every table and column ──────────────────────────
        self._registry.validate_query_plan(
            raw_plan.get("tables_needed", []),
            raw_plan.get("columns_needed", {}),
        )

        plan = QueryPlan(**{k: raw_plan[k] for k in QueryPlan.__dataclass_fields__
                            if k in raw_plan and k != "raw_sql"})

        # ── Build the final SQL ──────────────────────────────────────
        plan.raw_sql = self._build_sql(plan)
        return plan

    # ── SQL builder ──────────────────────────────────────────────────

    def _build_sql(self, plan: QueryPlan) -> str:
        # SELECT clause
        col_parts = []
        for tbl in plan.tables_needed:
            for col in plan.columns_needed.get(tbl, []):
                col_parts.append(f"{tbl}.{col}")
        if not col_parts:
            col_parts = [f"{plan.anchor_table}.*"]
        select_clause = ",\n       ".join(col_parts)

        sql = f"SELECT {select_clause}\nFROM   {plan.anchor_table}"

        # JOINs
        for join in plan.join_path:
            # Verify the join references valid tables
            if join["from"] != plan.anchor_table:
                sql += f"\nLEFT JOIN {join['from']} ON {join['on']}"
            else:
                sql += f"\nLEFT JOIN {join['to']}   ON {join['on']}"

        # WHERE — anchor filter first
        sql += (
            f"\nWHERE  {plan.anchor_table}.{plan.anchor_key_column}"
            f" = :record_id"
        )

        # Extra filter conditions (safe — LLM cannot inject; these are
        # checked against the schema before we get here)
        for cond in plan.filter_conditions:
            sql += f"\nAND    {cond}"

        # ORDER BY
        if plan.order_by:
            sql += "\nORDER BY " + ", ".join(plan.order_by)

        return sql
