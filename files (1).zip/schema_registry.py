"""
schema_registry.py
==================
Loads the JSON schema built by oracle_schema_discovery.py.
Provides helpers the LLM and query builder rely on:
  - get_llm_context()        compact text summary for LLM prompt
  - validate_query_plan()    whitelist check — no unknown tables/cols
  - get_join_path()          auto-resolve join between two tables
  - get_anchor_table()       find the right table for an entity hint
  - get_columns_for_table()  safe column list
"""

import json
from pathlib import Path


class SchemaRegistry:

    def __init__(self, schema_file: str):
        path = Path(schema_file)
        if not path.exists():
            raise FileNotFoundError(
                f"Schema file not found: {schema_file}\n"
                "Run oracle_schema_discovery.py first to generate it."
            )
        with open(path, encoding="utf-8") as f:
            self.schema = json.load(f)

        self._tables        = self.schema.get("tables", {})
        self._relationships = self.schema.get("relationships", [])
        self._patterns      = self.schema.get("common_query_patterns", [])

    # ── LLM context ─────────────────────────────────────────────────

    def get_llm_context(self, tables_hint: list = None) -> str:
        """
        Serialise the schema into a compact LLM-readable block.
        If tables_hint is provided, only include those tables (+ their
        direct relatives) to keep the prompt tight.
        """
        tables_to_include = set(tables_hint) if tables_hint else set(self._tables.keys())

        # Also include tables connected via relationships
        if tables_hint:
            for rel in self._relationships:
                if rel["parent_table"] in tables_to_include:
                    tables_to_include.add(rel["child_table"])
                if rel["child_table"] in tables_to_include:
                    tables_to_include.add(rel["parent_table"])

        lines = ["=== DATABASE SCHEMA (Oracle, no FK constraints) ===\n"]

        for tbl in sorted(tables_to_include):
            meta = self._tables.get(tbl)
            if not meta:
                continue
            pk_str = ", ".join(meta.get("primary_key", [])) or "unknown"
            lines.append(f"TABLE: {tbl}")
            lines.append(f"  Description    : {meta.get('description', '')}")
            lines.append(f"  Business scope : {meta.get('business_context', '')}")
            lines.append(f"  Primary key    : {pk_str}")
            lines.append("  Columns:")
            for col, info in meta.get("columns", {}).items():
                pk_marker  = " [PK]"  if info.get("primary_key")  else ""
                null_marker= " [NOT NULL]" if not info.get("nullable") else ""
                samples    = ""
                if info.get("sample_values"):
                    samples = "  e.g. " + ", ".join(info["sample_values"][:3])
                lines.append(
                    f"    {col:<35} {info.get('data_type',''):<20}"
                    f"{pk_marker}{null_marker}  — {info.get('description','')}"
                    f"{samples}"
                )
            lines.append("")

        lines.append("=== RELATIONSHIPS (use these for JOIN ON clauses) ===")
        for rel in self._relationships:
            if (rel["parent_table"] in tables_to_include or
                    rel["child_table"] in tables_to_include):
                lines.append(
                    f"  {rel['parent_table']}.{rel['parent_column']}"
                    f"  →  {rel['child_table']}.{rel['child_column']}"
                    f"  [{rel.get('join_type','LEFT JOIN')}]"
                    f"  ({rel.get('cardinality','ONE_TO_MANY')})"
                    f"  — {rel.get('description','')}"
                )
        lines.append("")
        lines.append("=== QUERY RULES ===")
        for rule in self.schema.get("llm_instructions", {}).get("safety_rules", []):
            lines.append(f"  • {rule}")

        return "\n".join(lines)

    # ── Validation ───────────────────────────────────────────────────

    def validate_query_plan(self, tables: list, columns: dict) -> bool:
        """
        Raises ValueError if LLM proposed unknown tables or columns.
        Always call this before executing any generated SQL.
        """
        for table in tables:
            if table not in self._tables:
                raise ValueError(
                    f"SECURITY: LLM proposed unknown table '{table}'. "
                    f"Known tables: {list(self._tables.keys())}"
                )
            for col in columns.get(table, []):
                if col not in self._tables[table]["columns"]:
                    raise ValueError(
                        f"SECURITY: LLM proposed unknown column '{col}' "
                        f"in table '{table}'."
                    )
        return True

    # ── Join resolution ──────────────────────────────────────────────

    def get_join_path(self, table_a: str, table_b: str) -> dict | None:
        for rel in self._relationships:
            if (rel["parent_table"] == table_a and rel["child_table"] == table_b):
                return rel
            if (rel["parent_table"] == table_b and rel["child_table"] == table_a):
                # Swap so caller always gets parent→child direction
                return {**rel,
                        "parent_table" : table_b,
                        "parent_column": rel["child_column"],
                        "child_table"  : table_a,
                        "child_column" : rel["parent_column"]}
        return None

    # ── Anchor table lookup ──────────────────────────────────────────

    def get_anchor_table(self, entity_hint: str) -> str | None:
        """
        Given a hint like "event" or "trade", find the most likely
        anchor table by matching against table names and descriptions.
        """
        hint = entity_hint.lower()
        # Exact substring match in table name
        for tbl in self._tables:
            if hint in tbl.lower():
                return tbl
        # Match in description / business_context
        for tbl, meta in self._tables.items():
            desc = (meta.get("description", "") + " " +
                    meta.get("business_context", "")).lower()
            if hint in desc:
                return tbl
        return None

    # ── Column helpers ───────────────────────────────────────────────

    def get_columns_for_table(self, table: str) -> list:
        return list(self._tables.get(table, {}).get("columns", {}).keys())

    def get_primary_key(self, table: str) -> list:
        return self._tables.get(table, {}).get("primary_key", [])

    def all_table_names(self) -> list:
        return list(self._tables.keys())
