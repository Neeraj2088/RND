"""
vector_store.py
===============
Abstracts ChromaDB (local) and Pinecone so the rest of the system
doesn't care which backend is used.

Supports:
  - search(query, top_k)  →  list of { text, metadata, score }
  - upsert(chunks)        →  load spec documents
"""

from __future__ import annotations
import os
from typing import List, Dict, Any
from config import Config


# ── Result dataclass ─────────────────────────────────────────────────────────

class SpecChunk:
    def __init__(self, text: str, metadata: dict, score: float):
        self.text     = text
        self.metadata = metadata   # e.g. {"source": "ISIN_spec.pdf", "page": 3}
        self.score    = score

    def __repr__(self):
        src = self.metadata.get("source", "unknown")
        return f"SpecChunk(score={self.score:.3f}, source={src})"


# ── Base interface ────────────────────────────────────────────────────────────

class BaseVectorStore:
    def search(self, query: str, top_k: int = 3) -> List[SpecChunk]:
        raise NotImplementedError

    def upsert(self, chunks: List[Dict[str, Any]]):
        """
        chunks: list of { "id": str, "text": str, "metadata": dict }
        """
        raise NotImplementedError


# ── ChromaDB (local, default) ─────────────────────────────────────────────────

class ChromaVectorStore(BaseVectorStore):
    """
    Uses sentence-transformers for embedding by default (no API key needed).
    Falls back to Anthropic embeddings if ANTHROPIC_API_KEY is set and
    USE_ANTHROPIC_EMBEDDINGS=true in .env
    """

    def __init__(self):
        try:
            import chromadb
            from chromadb.utils import embedding_functions as ef
        except ImportError:
            raise ImportError(
                "Install ChromaDB: pip install chromadb sentence-transformers"
            )

        use_anthropic_emb = os.getenv("USE_ANTHROPIC_EMBEDDINGS", "false").lower() == "true"

        if use_anthropic_emb and Config.ANTHROPIC_API_KEY:
            # Use Voyage AI via Anthropic for embeddings
            emb_fn = ef.create(
                model_name="voyage-2",
                api_key=Config.ANTHROPIC_API_KEY,
            )
        else:
            emb_fn = ef.DefaultEmbeddingFunction()  # all-MiniLM-L6-v2

        self._client = chromadb.PersistentClient(path=Config.VECTOR_DB_PATH)
        self._col    = self._client.get_or_create_collection(
            name               = Config.VECTOR_COLLECTION,
            embedding_function = emb_fn,
            metadata           = {"hnsw:space": "cosine"},
        )
        print(f"✅ ChromaDB loaded — collection '{Config.VECTOR_COLLECTION}' "
              f"({self._col.count()} chunks)")

    def search(self, query: str, top_k: int = 3) -> List[SpecChunk]:
        results = self._col.query(
            query_texts = [query],
            n_results   = min(top_k, max(self._col.count(), 1)),
        )
        chunks = []
        for text, meta, dist in zip(
            results["documents"][0],
            results["metadatas"][0],
            results["distances"][0],
        ):
            score = 1.0 - dist   # cosine distance → similarity
            chunks.append(SpecChunk(text=text, metadata=meta, score=score))
        return chunks

    def upsert(self, chunks: List[Dict[str, Any]]):
        ids      = [c["id"]       for c in chunks]
        texts    = [c["text"]     for c in chunks]
        metas    = [c.get("metadata", {}) for c in chunks]
        self._col.upsert(ids=ids, documents=texts, metadatas=metas)
        print(f"   Upserted {len(chunks)} chunks into ChromaDB.")


# ── Pinecone ─────────────────────────────────────────────────────────────────

class PineconeVectorStore(BaseVectorStore):

    def __init__(self):
        try:
            import pinecone
            from sentence_transformers import SentenceTransformer
        except ImportError:
            raise ImportError(
                "Install: pip install pinecone-client sentence-transformers"
            )
        pinecone.init(
            api_key     = Config.PINECONE_API_KEY,
            environment = Config.PINECONE_ENV,
        )
        self._index  = pinecone.Index(Config.PINECONE_INDEX)
        self._model  = SentenceTransformer("all-MiniLM-L6-v2")
        print(f"✅ Pinecone loaded — index '{Config.PINECONE_INDEX}'")

    def search(self, query: str, top_k: int = 3) -> List[SpecChunk]:
        vec     = self._model.encode(query).tolist()
        result  = self._index.query(vector=vec, top_k=top_k, include_metadata=True)
        chunks  = []
        for match in result["matches"]:
            chunks.append(SpecChunk(
                text     = match["metadata"].get("text", ""),
                metadata = match["metadata"],
                score    = match["score"],
            ))
        return chunks

    def upsert(self, chunks: List[Dict[str, Any]]):
        from sentence_transformers import SentenceTransformer
        model   = SentenceTransformer("all-MiniLM-L6-v2")
        vectors = []
        for c in chunks:
            vec = model.encode(c["text"]).tolist()
            meta = {**c.get("metadata", {}), "text": c["text"]}
            vectors.append((c["id"], vec, meta))
        self._index.upsert(vectors=vectors)
        print(f"   Upserted {len(chunks)} chunks into Pinecone.")


# ── Factory ───────────────────────────────────────────────────────────────────

def get_vector_store() -> BaseVectorStore:
    db_type = Config.VECTOR_DB_TYPE.lower()
    if db_type == "pinecone":
        return PineconeVectorStore()
    return ChromaVectorStore()
